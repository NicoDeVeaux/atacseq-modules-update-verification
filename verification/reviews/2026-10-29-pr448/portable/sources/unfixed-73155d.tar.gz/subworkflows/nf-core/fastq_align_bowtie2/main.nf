//
// Alignment with Bowtie2
//

include { BOWTIE2_ALIGN           } from '../../../modules/nf-core/bowtie2/align/main'
include { BAM_SORT_STATS_SAMTOOLS } from '../bam_sort_stats_samtools/main'

workflow FASTQ_ALIGN_BOWTIE2 {
    take:
    ch_reads // channel: [ val(meta), [ reads ] ]
    ch_index // channel: /path/to/bowtie2/index/
    save_unaligned // val
    sort_bam // val
    ch_fasta_fai // channel: [ val(meta), path(fasta), path(fai) ]

    main:

    //
    // Remap ch_fasta_fai to ch_fasta
    ch_fasta = ch_fasta_fai.map{ meta, fasta, _fai -> [ meta, fasta] }

    //
    // Map reads with Bowtie2
    //
    BOWTIE2_ALIGN(ch_reads, ch_index, ch_fasta, save_unaligned, sort_bam)

    //
    // Sort, index BAM file and run samtools stats, flagstat and idxstats
    //
    BAM_SORT_STATS_SAMTOOLS(BOWTIE2_ALIGN.out.bam, ch_fasta_fai)

    emit:
    bam_orig = BOWTIE2_ALIGN.out.bam // channel: [ val(meta), aligned ]
    log_out  = BOWTIE2_ALIGN.out.log // channel: [ val(meta), log     ]
    fastq    = BOWTIE2_ALIGN.out.fastq // channel: [ val(meta), fastq   ]
    bam      = BAM_SORT_STATS_SAMTOOLS.out.bam // channel: [ val(meta), [ bam ] ]
    index    = BAM_SORT_STATS_SAMTOOLS.out.index // channel: [ val(meta), [ index ] ]
    stats    = BAM_SORT_STATS_SAMTOOLS.out.stats // channel: [ val(meta), [ stats ] ]
    flagstat = BAM_SORT_STATS_SAMTOOLS.out.flagstat // channel: [ val(meta), [ flagstat ] ]
    idxstats = BAM_SORT_STATS_SAMTOOLS.out.idxstats // channel: [ val(meta), [ idxstats ] ]
}
