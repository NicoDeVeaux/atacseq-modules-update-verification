process PLOT_MACS3_QC {
    label 'process_medium'

    conda "conda-forge::r-base=4.0.3 conda-forge::r-reshape2=1.4.4 conda-forge::r-optparse=1.6.6 conda-forge::r-ggplot2=3.3.3 conda-forge::r-scales=1.1.1 conda-forge::r-viridis=0.5.1 conda-forge::r-tidyverse=1.3.0 bioconda::bioconductor-biostrings=2.58.0 bioconda::bioconductor-complexheatmap=2.6.2"
    container "${ workflow.containerEngine == 'singularity' && !task.ext.singularity_pull_docker_container ?
        'https://depot.galaxyproject.org/singularity/mulled-v2-ad9dd5f398966bf899ae05f8e7c54d0fb10cdfa7:05678da05b8e5a7a5130e90a9f9a6c585b965afa-0':
        'biocontainers/mulled-v2-ad9dd5f398966bf899ae05f8e7c54d0fb10cdfa7:05678da05b8e5a7a5130e90a9f9a6c585b965afa-0' }"

    input:
    path peaks
    val is_narrow_peak

    output:
    path '*.txt'       , emit: txt
    path '*.pdf'       , emit: pdf
    tuple val("${task.process}"), val('r-base'), eval("R --version | sed '1!d;s/.*version //;s/ .*//'"), topic: versions
    when:
    task.ext.when == null || task.ext.when

    script: // This script is bundled with the pipeline, in nf-core/atacseq/bin/
    def args      = task.ext.args ?: ''
    def peak_type = is_narrow_peak ? 'narrowPeak' : 'broadPeak'
    // Files arrive in task-completion order; sort so sample order in the outputs is reproducible.
    def peak_list = peaks.toSorted { peak -> peak.name }.join(',')
    """
    plot_macs3_qc.r \\
        -i ${peak_list} \\
        -s ${peak_list.replaceAll("_peaks.${peak_type}","")} \\
        $args

    """
}
