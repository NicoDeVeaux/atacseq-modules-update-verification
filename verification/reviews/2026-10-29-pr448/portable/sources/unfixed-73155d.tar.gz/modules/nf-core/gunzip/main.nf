process GUNZIP {
    tag "${archive}"
    label 'process_single'

    conda "${moduleDir}/environment.yml"
    container "${workflow.containerEngine in ['singularity', 'apptainer'] && !task.ext.singularity_pull_docker_container
        ? 'https://community-cr-prod.seqera.io/docker/registry/v2/blobs/sha256/52/52ccce28d2ab928ab862e25aae26314d69c8e38bd41ca9431c67ef05221348aa/data'
        : 'community.wave.seqera.io/library/coreutils_grep_gzip_lbzip2_pruned:838ba80435a629f8'}"

    input:
    tuple val(meta), path(archive)

    output:
    tuple val(meta), path("${gunzip}"), emit: gunzip
    tuple val("${task.process}"), val('gunzip'), eval('gunzip --version 2>&1 | head -1 | sed "s/^.*(gzip) //; s/ Copyright.*//"'), topic: versions, emit: versions_gunzip

    when:
    task.ext.when == null || task.ext.when

    script:
    def args = task.ext.args ?: ''
    def nameWithoutGz = archive.extension == 'gz' ? archive.baseName : archive.name
	def extension = file(nameWithoutGz).extension
	def name = file(nameWithoutGz).baseName
    def prefix = task.ext.prefix ?: name
    gunzip = prefix + ".${extension}"
    """
    # Not calling gunzip itself because it creates files
    # with the original group ownership rather than the
    # default one for that user / the work directory
    gzip \\
        -cd \\
        ${args} \\
        ${archive} \\
        > ${gunzip}
    """

    stub:
    def nameWithoutGz = archive.extension == 'gz' ? archive.baseName : archive.name
	def extension = file(nameWithoutGz).extension
	def name = file(nameWithoutGz).baseName
    def prefix = task.ext.prefix ?: name
    gunzip = prefix + ".${extension}"
    """
    touch ${gunzip}
    """
}
